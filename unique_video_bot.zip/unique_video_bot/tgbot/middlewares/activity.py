from datetime import datetime
from typing import Callable, Dict, Any, Awaitable

from aiogram import BaseMiddleware
from aiogram.types import Message

from infrastructure.database.repo.requests import update_user, user_is_registered, user_is_banned


class UserActivityMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Message,
        data: Dict[str, Any],
    ) -> Any:
        user_banned = await user_is_banned(event.from_user.id)
        if user_banned:
            return
        user_registered = await user_is_registered(event.from_user.id)
        if user_registered:
            await update_user(event.from_user.id, last_activity=datetime.now())
        return await handler(event, data)
